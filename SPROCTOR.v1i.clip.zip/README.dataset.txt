# SPROCTOR > 2023-10-07 4:02am
https://universe.roboflow.com/tanishaness/sproctor

Provided by a Roboflow user
License: CC BY 4.0

